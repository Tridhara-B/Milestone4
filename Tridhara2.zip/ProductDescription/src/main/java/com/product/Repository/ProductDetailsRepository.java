package com.product.Repository;



import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.product.Entity.ProductDetailsEntity;



@Repository
public interface ProductDetailsRepository extends JpaRepository<ProductDetailsEntity, Integer> {

	Optional<ProductDetailsEntity> findById(Integer id);
	//Optional<MarksEntity> findById(Integer id);
}

