package com.tridhara.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tridhara.entities.TBEntity;
import com.tridhara.repository.TBRepository;


@Service
public class TBServiceImpl implements TBService{
	
	@Autowired
	private TBRepository tbRepository;

	@Override
	public TBEntity create(TBEntity tbEntity) {
		return tbRepository.save(tbEntity);
	}

	@Override
	public Optional<TBEntity> getOne(Integer id) {
		return tbRepository.findById(id);
	}

	@Override
	public Optional<TBEntity> getByType(String type) {
		// TODO Auto-generated method stub
		return tbRepository.findByType(type);
	}

//	@Override
//	public StudentSMEntity create(StudentSMEntity ) {
//		return departmentRepository.save(departmentEntity);
//	}
//
//	@Override
//	public DepartmentEntity getOne(Integer deptId) {
//		return departmentRepository.findById(deptId).orElseThrow(()-> new RuntimeException("No Department found with id "+ deptId));
//	}
//
//	@Override
//	public List<DepartmentEntity> getAll() {
//		return departmentRepository.findAll();
//	}

}
