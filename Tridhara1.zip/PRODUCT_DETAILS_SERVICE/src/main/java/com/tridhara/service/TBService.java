package com.tridhara.service;

import java.util.Optional;

import com.tridhara.entities.TBEntity;

public interface TBService {
	
TBEntity create(TBEntity tbEntity);
	Optional<TBEntity> getOne(Integer id);
	Optional<TBEntity> getByType(String type);
	
//	List<DepartmentEntity> getAll();

}
