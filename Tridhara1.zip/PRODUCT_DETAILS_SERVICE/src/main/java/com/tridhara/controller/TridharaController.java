package com.tridhara.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tridhara.entities.TBEntity;
import com.tridhara.service.TBService;





@RestController
@RequestMapping("/product")
@CrossOrigin
public class TridharaController {

	@Autowired
	private TBService tbService;

	@GetMapping("/byid/{id}")
	public Optional<TBEntity> getById(@PathVariable Integer id) {
		return tbService.getOne(id);
	}
	
	@GetMapping("/bytype/{lname}")
	public Optional<TBEntity> getByType(@PathVariable String type){
		return tbService.getByType(type);
	}
	
	@PostMapping
	public TBEntity createSM(@RequestBody TBEntity tbEntity) {
		return tbService.create(tbEntity);
	}

}
