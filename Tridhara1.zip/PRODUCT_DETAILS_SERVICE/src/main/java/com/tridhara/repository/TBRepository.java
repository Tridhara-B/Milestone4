package com.tridhara.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tridhara.entities.TBEntity;


@Repository
public interface TBRepository extends JpaRepository<TBEntity, Integer>{
	Optional<TBEntity> findByType(String type);

}
