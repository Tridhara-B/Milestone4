package com.tridhara;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.tridhara.entities.TBEntity;
import com.tridhara.service.TBService;

@SpringBootApplication
@CrossOrigin
public class ProductDetailsServiceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(ProductDetailsServiceApplication.class, args);
		TBService service = context.getBean(TBService.class);
		service.create(new TBEntity(1,"mobile"));
		service.create(new TBEntity(2,"laptop"));
		service.create(new TBEntity(3,"laptop"));
	}

}
